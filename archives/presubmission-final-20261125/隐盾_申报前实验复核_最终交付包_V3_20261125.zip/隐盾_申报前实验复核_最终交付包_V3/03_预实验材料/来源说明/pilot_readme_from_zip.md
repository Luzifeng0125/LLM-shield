# PHASE3 预实验材料来源说明 · V3 路径版

[PHASE3 脱敏派生包](../PHASE3脱敏派生材料包.zip)保留了冻结时的 18 组合成材料和 README。归档内原文位于 `证据/experiments/third_stage/pilot_18/README.md`。[历史摘录](历史记录/pilot_readme_from_zip.md.txt)保留原始文字及历史目录含义。

| 历史 PHASE3 子目录（均在 pilot_18 下） | V3 阅读位置 |
| --- | --- |
| `source_materials/` | [组别目录](../G01-G18材料/)，每组的 source 子目录，例如 [G01 材料](../G01-G18材料/G01/source/材料.md) |
| `annotator_A/` | [A 材料](../A_B标注材料/A/)及[A 清单](annotation_A_manifest.csv) |
| `annotator_B/` | [B 材料](../A_B标注材料/B/)及[B 清单](annotation_B_manifest.csv) |
| `adjudication/` | 各组的 adjudication 子目录，例如 [G01 争议记录](../G01-G18材料/G01/adjudication/争议记录.md) |
| `metadata/groups.md` | [组织者分组索引](../G01-G18材料/_meta/metadata/groups.md) |
| `build_pilot.py` | [历史生成程序副本](../G01-G18材料/_meta/build_pilot.py) |

各组保留原文、文件名和标注规则。材料为合成虚构文本。两位标注者各自使用本人的材料和[原版手册](../../docs/reports/third_stage/隐盾_第三阶段人工标注手册_v1.md)。研究设计、模型输出、金标和仲裁信息仅供组织者依权限使用。正式标注及一致性统计均待开展。[分发边界](../../00_交付说明/README_交付说明.md)
