# PHASE3 来源与脱敏记录

原始归档只在本地保管。下列名称和 SHA-256 可区分原件及公开派生件。

| 对象 | 名称或位置 | SHA-256 |
| --- | --- | --- |
| 原始归档 | 隐盾_第三阶段PHASE3预实验准备_20261124.zip | 539e5ec6933f8b23b5f00361a1bcec52360ba2b874586359d82f176e4b0073a5 |
| V3 派生归档 | [PHASE3 脱敏派生材料包](../PHASE3脱敏派生材料包.zip) | 4321278193bc064e33226e5dcf2185500d73d8c89b650ee017778e9ad8ff7367 |

本地独立备份相对于项目工作区根目录的位置为 `隐盾_本地证据备份/申报前复核_V3_20261125/隐盾_第三阶段PHASE3预实验准备_20261124.zip`。逐处原文、行、列和替换值保存在同一备份目录的《PHASE3_七处替换原文_仅本地.csv》，其 SHA-256 为 0e3da38a7c775e12a24da9e20c135bfdcca90d3b0dac2f4c98c20e85d29c4685。

直接解压原件，仅将以下三份文档中的完整项目路径替换为字面量 `${PROJECT_ROOT}`。先匹配较长路径。行和列按原文 Unicode 字符从 1 起算。公开记录用原文字节的 UTF-8 SHA-256 标识原值，逐字原文由负责人持本地备份复核。

| 历史成员 | 替换次数 | 修改前 SHA-256 | 修改后 SHA-256 |
| --- | --- | --- | --- |
| 总结.md | 2 | 5f439236e5da27e15cf9bedad4e69a6366b3875952111e27b6b1242d1ae6fbba | 1bec339b77c820169a3f13ebc63af78ea74b277c36307346ecb8a9d24853fcee |
| 文档/隐盾_第三阶段PHASE3预实验准备与验收报告.md | 3 | d49c2101f69600437aa97952e05ea32c9d1e508390f1d1be3f87416ad68f7a4d | 6e84b854a5319b6dc73f2c9af19cf2fc5efef15f4d37270dca2326cde8f7cc3b |
| 文档/隐盾_第三阶段GitHub上传清单.md | 2 | f8ac33264aa0179f01f19f877ef97ff0875ebcd35918e2bd35a64737bbfc6e42 | a0059592ee1890912e9e1eb34cac6665fd90c244819d55def9d13976ca71f61e |

| 成员 | 原行 | 原列 | 原文 SHA-256 | 替换为 |
| --- | --- | --- | --- | --- |
| 总结.md | 7 | 27 | 9177315605dd97dfbf080a888a4df1c092eb3d7ba432d1d836b98a596b9ba76b | `${PROJECT_ROOT}` |
| 总结.md | 7 | 73 | 4d5f07bbb32a0f8c07ab4e679b82ec20d4e6090f5d5e94f7bc3440c3d427788a | `${PROJECT_ROOT}` |
| 文档/隐盾_第三阶段PHASE3预实验准备与验收报告.md | 5 | 54 | 9177315605dd97dfbf080a888a4df1c092eb3d7ba432d1d836b98a596b9ba76b | `${PROJECT_ROOT}` |
| 文档/隐盾_第三阶段PHASE3预实验准备与验收报告.md | 13 | 8 | 4d5f07bbb32a0f8c07ab4e679b82ec20d4e6090f5d5e94f7bc3440c3d427788a | `${PROJECT_ROOT}` |
| 文档/隐盾_第三阶段PHASE3预实验准备与验收报告.md | 15 | 8 | 9177315605dd97dfbf080a888a4df1c092eb3d7ba432d1d836b98a596b9ba76b | `${PROJECT_ROOT}` |
| 文档/隐盾_第三阶段GitHub上传清单.md | 7 | 27 | 9177315605dd97dfbf080a888a4df1c092eb3d7ba432d1d836b98a596b9ba76b | `${PROJECT_ROOT}` |
| 文档/隐盾_第三阶段GitHub上传清单.md | 29 | 4 | 4d5f07bbb32a0f8c07ab4e679b82ec20d4e6090f5d5e94f7bc3440c3d427788a | `${PROJECT_ROOT}` |

原包及派生包各有 180 个成员。其余 177 个成员的路径及原始字节逐项一致。全部成员的前后哈希见[V2 至 V3 逐文件清单](../../05_完整性校验/V2至V3_逐文件SHA256.csv)。
