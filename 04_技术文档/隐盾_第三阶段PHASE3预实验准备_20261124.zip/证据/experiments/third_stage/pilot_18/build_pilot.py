"""生成 18 组合成预实验材料。

这里不填写人工金标，也不调用 C3 或 C4。
标注者副本在生成时内容相同，之后由两人各自填写。
"""
from __future__ import annotations

import hashlib
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HANDBOOK = "../../../../docs/reports/third_stage/隐盾_第三阶段人工标注手册_v1.md"

INSTRUCTION = """# 标注说明

本文件夹只给你本人使用。另一位标注者有一份独立副本，不要打开，也不要对照。

材料是合成虚构的校园协作文本，不是真实采集数据。文中的人名不对应真实个人。

请按手册顺序填写空白表：先定位和修订，再核对候选身份，然后分别根据锚点原文和披露句填写维度。链接不看披露结论。更新关系单独填写。四态最后填写。

不要把本文件夹以外的模型输出、C3 结果或别人的标注抄进来。冻结方案第 12 节的分组表是研究设计，标注期间不要用它来填写四态。

允许的 kind 只有 value、unmentioned、not_applicable、unparsable。状态只使用手册中的九个业务值。「核准」在规则标注里是 unparsable。「尚未批准」不是已否决。

定位失败、没有锚点或同一引文不能唯一对应时，四态填写 paused。一组里有一条 invalid 或 paused，整组不交付。本表不填写六动作，也不填写外发许可。

分歧留在仲裁目录，由第三人填写。两位原标注者不要把自己的分歧改成一致。

手册：{handbook}
"""

FORM = """# 空白标注表

标注者：
日期：
文档组：{gid}
划分：预实验 18 组
任务模板：{template}
材料性质：合成虚构

## 1. 修订

| 项 | 填写 |
| --- | --- |
| 当前修订号 |  |
| 父修订号 |  |
| 当前引文指纹是否与快照相同 |  |

## 2. 锚点

每个锚点一行。没有锚点就留空，并在四态填写 paused。

| 锚点 | 修订 | 原文是否与材料一致 | 备注 |
| --- | --- | --- | --- |
|  |  |  |  |

## 3. 证据断言

每个锚点、每个维度一行。kind 和规范值都先留空。

| 锚点 | 维度 | kind | 规范值 | 依据原文 |
| --- | --- | --- | --- | --- |
|  | subject |  |  |  |
|  | attribute |  |  |  |
|  | context_scope |  |  |  |
|  | grain |  |  |  |
|  | numeric_value |  |  |  |
|  | unit |  |  |  |
|  | valid_time |  |  |  |
|  | polarity |  |  |  |
|  | status |  |  |  |

## 4. 结论断言

只看披露句，不把证据里的值抄进结论。

| 结论 | 维度 | kind | 规范值 |
| --- | --- | --- | --- |
|  | subject |  |  |
|  | attribute |  |  |
|  | context_scope |  |  |
|  | grain |  |  |
|  | numeric_value |  |  |
|  | unit |  |  |
|  | valid_time |  |  |
|  | polarity |  |  |
|  | status |  |  |

## 5. 身份链接

不看披露结论，不看模型输出。

| 当前锚点 | link_type | 目标锚点 | basis_span | basis_start | basis_end |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 6. 更新关系

身份链接本身不填写更新。

| 当前锚点 | relation | updated_dimensions | basis_span | basis_start | basis_end |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

## 7. 四态

| 对象 | 四态 | 简要理由 |
| --- | --- | --- |
| 结论甲 |  |  |
| 结论乙 |  |  |
| 结论丙 |  |  |
| 整组 |  |  |

没有第三句结论时，结论丙整行留空。
"""

ADJUDICATION = """# 争议记录

文档组：{gid}
状态：尚未开始。两位标注者完成之前，本表保持空白。

| 字段 | 标注者 A | 标注者 B | 仲裁结果 | 仲裁人 | 日期 |
| --- | --- | --- | --- | --- | --- |
|  |  |  |  |  |  |

仲裁只处理分歧字段，不改已经一致的字段，也不发明词表外的状态。
"""


def _doc(title: str, template: str, body: str) -> str:
    return (
        f"# {title}\n\n"
        "材料性质：合成虚构。本文件不是真实采集的校园文档，人名不对应真实个人。\n"
        f"任务模板：{template}\n"
        "划分：预实验 18 组。不进入开发集、验证集或测试集。\n\n"
        f"{body.strip()}\n"
    )


GROUPS = [
    {
        "id": "G01",
        "template": "activity_stats",
        "purpose": "同一锚点的父修订把志愿者人数从 12 改为 15。",
        "coverage": "文档修订、数值变化",
        "body": """
## 父修订 rev-g01-old
- block:count：2026年3月阅读马拉松的志愿者人数为 12 人。
- block:place：阅读马拉松的地点为图书馆一楼大厅。

## 当前修订 rev-g01
父修订号：rev-g01-old。引文指纹已变化。
- block:count：2026年3月阅读马拉松的志愿者人数为 15 人。
- block:place：阅读马拉松的地点为图书馆一楼大厅。

## 待判断结论
- 结论甲：2026年3月阅读马拉松的志愿者人数为 12 人。
- 结论乙：阅读马拉松的地点为图书馆一楼大厅。
""",
    },
    {
        "id": "G02",
        "template": "meeting_minutes",
        "purpose": "已批准的印刷预算由 8000 元改为 9000 元。",
        "coverage": "文档修订、数值与单位、状态",
        "body": """
## 父修订 rev-g02-old
- block:money：春季展板印刷预算已批准，金额为 8000 元。
- block:place：展板领取地点为设计楼大厅。

## 当前修订 rev-g02
父修订号：rev-g02-old。引文指纹已变化。
- block:money：春季展板印刷预算已批准，金额为 9000 元。
- block:place：展板领取地点为设计楼大厅。

## 待判断结论
- 结论甲：春季展板印刷预算已经批准为 8000 元。
- 结论乙：展板领取地点为设计楼大厅。
""",
    },
    {
        "id": "G03",
        "template": "activity_notice",
        "purpose": "海报截止日期从 3 月 20 日改为 4 月 2 日。",
        "coverage": "文档修订、有效时间",
        "body": """
## 父修订 rev-g03-old
- block:due：招新海报的截止日期为 2026年3月20日。
- block:role：招新海报的负责人是宣传组。

## 当前修订 rev-g03
父修订号：rev-g03-old。引文指纹已变化。
- block:due：招新海报的截止日期为 2026年4月2日。
- block:role：招新海报的负责人是宣传组。

## 待判断结论
- 结论甲：招新海报的截止日期为 2026年3月20日。
- 结论乙：招新海报的负责人是宣传组。
""",
    },
    {
        "id": "G04",
        "template": "meeting_minutes",
        "purpose": "词表内改写另含一条「核准」。核准不加入 C3 词表，本组只供方法调整。",
        "coverage": "状态变化、非显式状态、文档修订",
        "body": """
## 父修订 rev-g04-old
- block:fee：建议将排练室使用费调整为 500 元。
- block:place：排练室地点为艺术楼 203。

## 当前修订 rev-g04
父修订号：rev-g04-old。引文指纹已变化。
- block:fee：排练室使用费已批准，金额为 500 元。
- block:sponsor：外联赞助已核准。
- block:place：排练室地点为艺术楼 203。

## 待判断结论
- 结论甲：排练室使用费已经批准为 500 元。
- 结论乙：外联赞助已批准。
- 结论丙：排练室地点为艺术楼 203。
""",
    },
    {
        "id": "G05",
        "template": "meeting_minutes",
        "purpose": "父节只有一笔预算，当前句用「该预算」指向它，并只写出批准。",
        "coverage": "显式指代、多证据部分支持",
        "body": """
## 当前修订 rev-g05
无父修订。
- block:fee：拟把义卖摊位预算定为 600 元。
- block:decision：该预算已经批准。
- block:place：义卖地点为操场东侧。

## 待判断结论
- 结论甲：义卖摊位预算已经批准为 600 元。
- 结论乙：义卖地点为操场东侧。
""",
    },
    {
        "id": "G06",
        "template": "meeting_minutes",
        "purpose": "两处李明没有社团、班级或其他区分信息。另有一句「此人」没有显式指代词。",
        "coverage": "拒判、非显式指代",
        "body": """
## 当前修订 rev-g06
无父修订。
- block:p1：李明到场。
- block:p2：签到表另一行也记录李明到场。
- block:p3：此人已签到。
- block:place：招募会地点为学生活动中心。

## 待判断结论
- 结论甲：李明参加了周六的招募会。
- 结论乙：招募会地点为学生活动中心。
""",
    },
    {
        "id": "G07",
        "template": "meeting_minutes",
        "purpose": "两个王磊分别属于计算机协会和文学社，结论把职务对调。",
        "coverage": "主体区分、状态或职务变化",
        "body": """
## 当前修订 rev-g07
无父修订。
- block:cs：计算机协会的王磊负责海报。
- block:lit：文学社的王磊负责签到。

## 待判断结论
- 结论甲：计算机协会的王磊负责签到。
- 结论乙：文学社的王磊负责签到。
""",
    },
    {
        "id": "G08",
        "template": "activity_stats",
        "purpose": "读书会报名写的是尚未达到 12 人。",
        "coverage": "极性变化",
        "body": """
## 当前修订 rev-g08
无父修订。
- block:count：截至本周五，读书会报名尚未达到 12 人。
- block:place：读书会地点为文科楼 105。

## 待判断结论
- 结论甲：读书会报名人数达到 12 人。
- 结论乙：读书会地点为文科楼 105。
""",
    },
    {
        "id": "G09",
        "template": "meeting_minutes",
        "purpose": "主句是尚未批准，副句是未获批准。",
        "coverage": "状态变化、拒判",
        "body": """
## 当前修订 rev-g09
无父修订。
- block:reg：社团登记尚未批准。
- block:subsidy：活动补贴未获批准。
- block:place：社团办公室地点为行政楼 102。

## 待判断结论
- 结论甲：社团登记已批准。
- 结论乙：活动补贴已批准。
- 结论丙：社团办公室地点为行政楼 102。
""",
    },
    {
        "id": "G10",
        "template": "meeting_minutes",
        "purpose": "材料只写出横幅费用的建议，结论写成已经批准。",
        "coverage": "状态变化",
        "body": """
## 当前修订 rev-g10
无父修订。
- block:fee：建议将迎新横幅费用调整为 300 元。
- block:place：横幅悬挂地点为南门。

## 待判断结论
- 结论甲：迎新横幅费用已经批准为 300 元。
- 结论乙：横幅悬挂地点为南门。
""",
    },
    {
        "id": "G11",
        "template": "meeting_minutes",
        "purpose": "保险名单仍是计划，结论写成已完成。",
        "coverage": "状态变化",
        "body": """
## 当前修订 rev-g11
无父修订。
- block:task：计划在周五前交齐志愿者保险名单。
- block:place：保险办理地点为校医院服务台。

## 待判断结论
- 结论甲：志愿者保险名单已完成。
- 结论乙：保险办理地点为校医院服务台。
""",
    },
    {
        "id": "G12",
        "template": "meeting_minutes",
        "purpose": "采购清单只写已批准，结论写成已完成。",
        "coverage": "状态变化",
        "body": """
## 当前修订 rev-g12
无父修订。
- block:task：采购清单已批准。
- block:place：采购领取地点为后勤仓库。

## 待判断结论
- 结论甲：采购清单已完成。
- 结论乙：采购领取地点为后勤仓库。
""",
    },
    {
        "id": "G13",
        "template": "activity_stats",
        "purpose": "同一个五月班会同时留下 12 人和 15 人，没有修订。",
        "coverage": "证据冲突、有效时间",
        "body": """
## 当前修订 rev-g13
无父修订。
- block:left：2026年5月班会到场人数为 12 人。
- block:right：2026年5月班会到场人数为 15 人。
- block:place：班会地点为教学楼 201。

## 待判断结论
- 结论甲：2026年5月班会到场人数为 12 人。
- 结论乙：班会地点为教学楼 201。
""",
    },
    {
        "id": "G14",
        "template": "meeting_minutes",
        "purpose": "同一校车申请同时留下已批准和已否决，没有修订。",
        "coverage": "证据冲突、状态变化",
        "body": """
## 当前修订 rev-g14
无父修订。
- block:yes：校车增开申请已批准。
- block:no：校车增开申请已否决。
- block:place：校车停靠地点为西门。

## 待判断结论
- 结论甲：校车增开申请已批准。
- 结论乙：校车停靠地点为西门。
""",
    },
    {
        "id": "G15",
        "template": "meeting_minutes",
        "purpose": "物资领用段已删除，当前修订没有留下可定位原文。",
        "coverage": "证据缺失",
        "body": """
## 父修订 rev-g15-old
- block:gloves：手套领用数量为 40 双。
- block:hours：仓库开放时间为每周三下午。

## 当前修订 rev-g15
父修订号：rev-g15-old。修订说明写明原领用段已删除。
- 手套领用没有锚点，也没有保留原文。
- block:hours：仓库开放时间为每周三下午。

## 待判断结论
- 结论甲：手套领用数量为 40 双。
- 结论乙：仓库开放时间为每周三下午。
""",
    },
    {
        "id": "G16",
        "template": "activity_stats",
        "purpose": "同一参赛记录由全体 20 人改为不含工作人员 16 人。",
        "coverage": "文档修订、口径与数值",
        "body": """
## 父修订 rev-g16-old
表格业务键 row:race。列：人数。口径格：全体。
- row:race：20

## 当前修订 rev-g16
父修订号：rev-g16-old。同一业务键。列：人数。口径格：不含工作人员。
- row:race：16
- block:place：比赛地点为体育馆。

## 待判断结论
- 结论甲：全体参赛人数为 20 人。
- 结论乙：比赛地点为体育馆。
""",
    },
    {
        "id": "G17",
        "template": "activity_notice",
        "purpose": "披露点名的 block:poster-3 在当前文档中不存在。",
        "coverage": "证据缺失、拒判",
        "body": """
## 当前修订 rev-g17
无父修订。精确检索 block:poster-3 的结果为零。
- block:poster-1：开幕通知已张贴。
- 不存在 block:poster-3。

## 待判断结论
- 结论甲：海报印刷已完成。该结论指定的锚点是 block:poster-3。
- 结论乙：开幕通知已张贴。
""",
    },
    {
        "id": "G18",
        "template": "activity_notice",
        "purpose": "同一句开幕式地点出现在两个锚点，不能唯一对应。",
        "coverage": "拒判、定位",
        "body": """
## 当前修订 rev-g18
无父修订。
- block:q1：开幕式在大学生活动中心举行。
- block:q2：开幕式在大学生活动中心举行。
- block:date：开幕式日期为 2026年5月8日。

## 待判断结论
- 结论甲：开幕式在大学生活动中心举行。
- 结论乙：开幕式日期为 2026年5月8日。
""",
    },
]


def _clean_output() -> None:
    for name in ("source_materials", "annotator_A", "annotator_B", "adjudication"):
        folder = ROOT / name
        if folder.exists():
            shutil.rmtree(folder)


def build() -> None:
    _clean_output()
    lines = [
        "# 18 组研究设计索引",
        "",
        "本文件给组织标注的人使用，不要放进标注者文件夹。",
        "这里不写四态答案。分组目的以冻结方案第 12 节为准，本索引只说明每组材料在看什么。",
        "",
        "| 组 | 主要目的 | 覆盖 |",
        "| --- | --- | --- |",
    ]
    for group in GROUPS:
        gid = group["id"]
        text = _doc(gid, group["template"], group["body"])
        (ROOT / "source_materials" / gid).mkdir(parents=True)
        (ROOT / "source_materials" / gid / "材料.md").write_text(text, encoding="utf-8")
        packet = {
            "材料.md": text,
            "标注说明.md": INSTRUCTION.format(handbook=HANDBOOK),
            "空白标注表.md": FORM.format(gid=gid, template=group["template"]),
        }
        for person in ("annotator_A", "annotator_B"):
            folder = ROOT / person / gid
            folder.mkdir(parents=True)
            for name, content in packet.items():
                (folder / name).write_text(content, encoding="utf-8")
        (ROOT / "adjudication" / gid).mkdir(parents=True)
        (ROOT / "adjudication" / gid / "争议记录.md").write_text(
            ADJUDICATION.format(gid=gid), encoding="utf-8"
        )
        lines.append(f"| {gid} | {group['purpose']} | {group['coverage']} |")
    lines.append("")
    lines.append("人工标注尚未开始。生成程序没有调用 L3、L4、C3 或 C4。")
    lines.append("")
    (ROOT / "metadata").mkdir(exist_ok=True)
    (ROOT / "metadata" / "groups.md").write_text("\n".join(lines), encoding="utf-8")


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify() -> None:
    ids = [group["id"] for group in GROUPS]
    if ids != [f"G{i:02d}" for i in range(1, 19)]:
        raise SystemExit("组号不完整")
    for gid in ids:
        left = ROOT / "annotator_A" / gid
        right = ROOT / "annotator_B" / gid
        names = sorted(path.name for path in left.iterdir())
        if names != sorted(path.name for path in right.iterdir()):
            raise SystemExit(f"{gid} 两份副本文件不同")
        for name in names:
            if _sha(left / name) != _sha(right / name):
                raise SystemExit(f"{gid} {name} 内容不同")
            text = (left / name).read_text(encoding="utf-8")
            if "C3输出" in text or "C4输出" in text:
                raise SystemExit(f"{gid} 含有模型输出")
        form = (left / "空白标注表.md").read_text(encoding="utf-8")
        if "still_valid" in form or "invalid" in form:
            raise SystemExit(f"{gid} 空白表写了四态答案")
        material = (ROOT / "source_materials" / gid / "材料.md").read_text(encoding="utf-8")
        if "合成虚构" not in material:
            raise SystemExit(f"{gid} 未标明合成")
        if "1" in material and any(token in material for token in ("学号", "手机", "电话")):
            raise SystemExit(f"{gid} 出现个人标识字段")
    print("pilot structure ok", len(ids))


if __name__ == "__main__":
    build()
    verify()
