# 第三阶段实验模块

本目录实现冻结方案中的公共候选注册表、Context Package、L3、L4 和 C3。C4 只有接口。这里不调用产品暂停、预检或外发。

## 数据流

1. `canonical.py` 统一换行，并按 Unicode 码位记录偏移。
2. `registry.py` 只根据锚点建立 R0。它不读披露结论、金标、金额、单位、状态、极性或有效时间。
3. `context.py` 把冻结后的注册表和当前证据交给两个通道。两个通道看到同一份输入。
4. `extract.py` 从锚点原文提取证据断言。
5. `c3.py` 只在显式词且候选恰好一个时提出链接。其余情况拒绝。
6. `l4.py` 按冻结方案第 7.2 节的闭包比较结论和活动证据，给出四态。
7. `c4_interface.py` 在没有获准模型时直接拒绝。

夹具定义在 `cases.py`，导出文件是 `fixtures/t1_t13.json`。导出结果必须与生成器一致。执行状态保持 `pending_l3_l4`，测试通过不把该字段改成 `passed`。

18 组预实验在 `pilot_18/`。材料是合成文本，人工标注尚未开始。

## 运行

在仓库根目录执行：

```text
python -m unittest experiments.third_stage.tests.test_foundation experiments.third_stage.tests.test_l3_l4_c3 experiments.third_stage.tests.test_pilot_18
```

修改夹具定义后执行：

```text
python -m experiments.third_stage.export_fixtures
```

夹具使用的 `example-only-not-for-real-data` 只用于示例，不能用于真实数据。
