"""18 组预实验材料的结构检查。不代替人工标注，也不调用 L4。"""
from __future__ import annotations

import unittest

from experiments.third_stage.cases import materialize_suite
from experiments.third_stage.pilot_18.build_pilot import GROUPS, build, verify


class PilotMaterialTests(unittest.TestCase):
    def test_eighteen_groups_are_complete_and_independent(self):
        self.assertEqual(len(GROUPS), 18)
        self.assertEqual([group["id"] for group in GROUPS], [f"G{i:02d}" for i in range(1, 19)])
        bodies = [group["body"].strip() for group in GROUPS]
        self.assertEqual(len(bodies), len(set(bodies)))
        build()
        verify()

    def test_materials_do_not_copy_fixture_sentences(self):
        fixture_lines = set()
        for case in materialize_suite()["cases"]:
            for anchor in case["anchors"]:
                fixture_lines.add(anchor["raw_text"])
            fixture_lines.add(case["claim"]["text"])
        for group in GROUPS:
            for line in group["body"].splitlines():
                sentence = line.split("：", 1)[-1].strip()
                if sentence:
                    self.assertNotIn(sentence, fixture_lines)


if __name__ == "__main__":
    unittest.main()
