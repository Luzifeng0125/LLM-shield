# 18 组预实验材料

这是冻结研究方案第 12 节的预实验材料，不是 36 组正式实验，也不是已经完成的标注。

全部文本都是合成虚构的校园协作材料。文中人名不对应真实个人。没有真实采集原文，因此没有需要单独隔离的敏感原件。

## 目录

- `source_materials/`：每组一份阅读材料。
- `annotator_A/`、`annotator_B/`：生成时内容相同的独立副本。两人填写后不要互相查看。
- `adjudication/`：空白争议记录。第三人在两人完成后填写。
- `metadata/groups.md`：给组织者看的研究目的。不写四态答案，不要发给标注者。
- `build_pilot.py`：重新生成上述材料。

## 当前状态

人工标注尚未开始。生成程序没有调用 L3、L4、C3 或 C4，也没有把自动结果写成金标。

标注者只使用自己的副本和 `docs/reports/third_stage/隐盾_第三阶段人工标注手册_v1.md`。标注期间不要对照冻结方案第 12 节的分组表来填写四态。

## 重新生成

在仓库根目录执行：

```text
python -m experiments.third_stage.pilot_18.build_pilot
python -m unittest experiments.third_stage.tests.test_pilot_18
```

结构检查只确认 18 组齐全、两份副本一致、材料标明合成，并且没有整句复制 T1—T13。它不计算一致性，也不判断四态。
