# 三项已知差异
日期：2026-11-25。运行基线：工作区 experiments/third_stage，HEAD e9e16b8。未修改冻结金标。
## T12-a
- 预期四态：still_valid
- 实际四态：paused
- 实际冲突：none
- claim_relation：null
- reasons：['comparison_finished']
- 说明：预算金额要求状态维。当前工作区原文与结论未写批准状态，算法按规则暂停。不得为匹配旧金标直接放行。PHASE3 压缩包另有输入补全修订，不并入本轮工作区。
## T7
- 预期四态：paused；实际：paused
- 预期冲突：conflict；实际：conflict
- 金标断言：{"block:c12": {"numeric_value": {"kind": "value", "value": "12"}, "valid_time": {"kind": "value", "value": "2026-03"}}, "block:c15": {"numeric_value": {"kind": "value", "value": "15"}, "valid_time": {"kind": "value", "value": "2026-03"}}}
- 说明：四态与冲突与金标一致。金标里的 valid_time=2026-03 不能从原文得到。测试 test_known_gold_deltas_are_exact_and_not_relabelled 锁定该断言差异。不得从金标补写原文日期。
## T7-a
- 预期四态：paused；实际：paused
- 预期冲突：conflict；实际：conflict
- 金标断言：{"block:m8": {"numeric_value": {"kind": "value", "value": "8000"}, "valid_time": {"kind": "value", "value": "2026-03"}}, "block:m9": {"numeric_value": {"kind": "value", "value": "9000"}, "valid_time": {"kind": "value", "value": "2026-03"}}}
- 说明：四态与冲突与金标一致。金标里的 valid_time=2026-03 不能从原文得到。测试 test_known_gold_deltas_are_exact_and_not_relabelled 锁定该断言差异。不得从金标补写原文日期。
## T13-c
- 预期四态：paused；实际：paused
- 预期冲突：none；实际：conflict
- reasons：['source_conflict']
- 说明：最终四态同为 paused。冲突标签实际为 conflict，金标仍为 none。链接拒绝不取消金额冲突。差异已锁定，不得隐藏。
